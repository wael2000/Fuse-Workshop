package org.switchyard.quickstarts.camel.saxon;

public interface GoodbyeService {
    void greet(String name);
}
